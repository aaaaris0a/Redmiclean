package com.redmicleaner.app.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.redmicleaner.app.data.database.dao.CacheCleanerDao
import com.redmicleaner.app.data.database.dao.MemoryOptimizerDao
import com.redmicleaner.app.data.database.dao.PrivacyProtectionDao
import com.redmicleaner.app.data.database.dao.ResidualCleanerDao
import com.redmicleaner.app.data.database.entity.AppCacheEntity
import com.redmicleaner.app.data.database.entity.AppInfoEntity
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import com.redmicleaner.app.data.database.entity.PrivacyRiskEntity
import com.redmicleaner.app.data.database.entity.ResidualFileEntity

@Database(
    entities = [
        AppCacheEntity::class,
        AppInfoEntity::class,
        CleanHistoryEntity::class,
        PrivacyRiskEntity::class,
        ResidualFileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CleanerDatabase : RoomDatabase() {
    abstract fun cacheCleanerDao(): CacheCleanerDao
    abstract fun memoryOptimizerDao(): MemoryOptimizerDao
    abstract fun residualCleanerDao(): ResidualCleanerDao
    abstract fun privacyProtectionDao(): PrivacyProtectionDao
}
