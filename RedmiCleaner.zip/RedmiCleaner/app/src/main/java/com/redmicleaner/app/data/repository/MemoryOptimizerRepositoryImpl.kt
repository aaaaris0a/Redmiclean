package com.redmicleaner.app.data.repository

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Process
import com.redmicleaner.app.data.database.dao.MemoryOptimizerDao
import com.redmicleaner.app.data.database.entity.AppInfoEntity
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import javax.inject.Inject

class MemoryOptimizerRepositoryImpl @Inject constructor(
    private val context: Context,
    private val memoryOptimizerDao: MemoryOptimizerDao
) : MemoryOptimizerRepository {

    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    override suspend fun scanRunningApps(): List<AppInfoEntity> = withContext(Dispatchers.IO) {
        val packageManager = context.packageManager
        val runningAppProcesses = activityManager.runningAppProcesses ?: emptyList()
        val appInfos = mutableListOf<AppInfoEntity>()
        
        for (process in runningAppProcesses) {
            try {
                // 跳过系统进程
                if (process.processName.startsWith("system:") || 
                    process.processName.startsWith("android:") ||
                    process.processName == "com.redmicleaner.app") {
                    continue
                }
                
                val packageName = process.processName
                val applicationInfo = packageManager.getApplicationInfo(packageName, 0)
                val appName = packageManager.getApplicationLabel(applicationInfo).toString()
                
                // 获取内存使用情况
                val memoryInfo = ActivityManager.RunningAppProcessInfo()
                val pids = intArrayOf(process.pid)
                val memoryUsage = activityManager.getProcessMemoryInfo(pids)[0].totalPss * 1024L // 转换为字节
                
                val isSystemApp = (applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                
                val appInfo = AppInfoEntity(
                    packageName = packageName,
                    appName = appName,
                    versionName = packageManager.getPackageInfo(packageName, 0).versionName,
                    installTime = packageManager.getPackageInfo(packageName, 0).firstInstallTime,
                    lastUpdateTime = packageManager.getPackageInfo(packageName, 0).lastUpdateTime,
                    isSystemApp = isSystemApp,
                    memoryUsage = memoryUsage,
                    batteryUsage = 0f, // 需要通过BatteryStats API获取，这里简化处理
                    dataUsage = 0L, // 需要通过NetworkStatsManager获取，这里简化处理
                    lastUsedTime = System.currentTimeMillis()
                )
                
                appInfos.add(appInfo)
                memoryOptimizerDao.insertAppInfo(appInfo)
            } catch (e: Exception) {
                // 忽略无法访问的应用
                e.printStackTrace()
            }
        }
        
        return@withContext appInfos
    }
    
    override suspend fun getAppInfoByPackage(packageName: String): AppInfoEntity? {
        return memoryOptimizerDao.getAppInfoByPackage(packageName)
    }
    
    override fun getAllAppInfos(): Flow<List<AppInfoEntity>> {
        return memoryOptimizerDao.getAllAppInfos()
    }
    
    override fun getNonSystemApps(): Flow<List<AppInfoEntity>> {
        return memoryOptimizerDao.getNonSystemApps()
    }
    
    override fun getSystemApps(): Flow<List<AppInfoEntity>> {
        return memoryOptimizerDao.getSystemApps()
    }
    
    override suspend fun getTotalMemoryUsage(): Long {
        return memoryOptimizerDao.getTotalMemoryUsage() ?: 0L
    }
    
    override suspend fun getAvailableMemory(): Long {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.availMem
    }
    
    override suspend fun getTotalMemory(): Long {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.totalMem
    }
    
    override suspend fun killApp(packageName: String): Boolean = withContext(Dispatchers.IO) {
        try {
            // 获取应用的内存使用量
            val appInfo = memoryOptimizerDao.getAppInfoByPackage(packageName)
            
            // 使用ActivityManager强制停止应用
            activityManager.killBackgroundProcesses(packageName)
            
            // 从数据库中删除应用信息
            memoryOptimizerDao.deleteAppInfo(packageName)
            
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        }
    }
    
    override suspend fun killSelectedApps(packageNames: List<String>): Long = withContext(Dispatchers.IO) {
        var totalFreedMemory = 0L
        
        for (packageName in packageNames) {
            val appInfo = getAppInfoByPackage(packageName)
            if (appInfo != null) {
                val memoryUsage = appInfo.memoryUsage
                val success = killApp(packageName)
                if (success) {
                    totalFreedMemory += memoryUsage
                }
            }
        }
        
        return@withContext totalFreedMemory
    }
    
    override suspend fun killAllApps(): Long = withContext(Dispatchers.IO) {
        val nonSystemApps = memoryOptimizerDao.getNonSystemApps().first()
        val packageNames = nonSystemApps.map { it.packageName }
        return@withContext killSelectedApps(packageNames)
    }
    
    override suspend fun optimizeMemory(): Long = withContext(Dispatchers.IO) {
        // 1. 获取当前内存使用情况
        val beforeAvailableMemory = getAvailableMemory()
        
        // 2. 清理所有非系统应用
        killAllApps()
        
        // 3. 清理系统缓存
        System.gc()
        
        // 4. 等待一段时间让系统完成清理
        Thread.sleep(1000)
        
        // 5. 获取优化后的内存使用情况
        val afterAvailableMemory = getAvailableMemory()
        
        // 6. 计算释放的内存
        val freedMemory = afterAvailableMemory - beforeAvailableMemory
        
        return@withContext if (freedMemory > 0) freedMemory else 0L
    }
    
    override suspend fun saveCleanHistory(freedMemory: Long, details: String) {
        val cleanHistory = CleanHistoryEntity(
            cleanType = "MEMORY",
            cleanTime = System.currentTimeMillis(),
            cleanedSize = freedMemory,
            details = details
        )
        memoryOptimizerDao.insertCleanHistory(cleanHistory)
    }
    
    override fun getCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>> {
        return memoryOptimizerDao.getMemoryCleanHistory(limit)
    }
}
