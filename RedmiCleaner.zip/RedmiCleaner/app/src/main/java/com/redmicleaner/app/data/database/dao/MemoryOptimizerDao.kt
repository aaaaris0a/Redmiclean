package com.redmicleaner.app.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.redmicleaner.app.data.database.entity.AppInfoEntity
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryOptimizerDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppInfo(appInfo: AppInfoEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppInfos(appInfos: List<AppInfoEntity>)
    
    @Query("SELECT * FROM app_info ORDER BY memoryUsage DESC")
    fun getAllAppInfos(): Flow<List<AppInfoEntity>>
    
    @Query("SELECT * FROM app_info WHERE packageName = :packageName")
    suspend fun getAppInfoByPackage(packageName: String): AppInfoEntity?
    
    @Query("SELECT SUM(memoryUsage) FROM app_info")
    suspend fun getTotalMemoryUsage(): Long?
    
    @Query("SELECT * FROM app_info WHERE isSystemApp = 0 ORDER BY memoryUsage DESC")
    fun getNonSystemApps(): Flow<List<AppInfoEntity>>
    
    @Query("SELECT * FROM app_info WHERE isSystemApp = 1 ORDER BY memoryUsage DESC")
    fun getSystemApps(): Flow<List<AppInfoEntity>>
    
    @Query("UPDATE app_info SET memoryUsage = :memoryUsage WHERE packageName = :packageName")
    suspend fun updateAppMemoryUsage(packageName: String, memoryUsage: Long)
    
    @Query("DELETE FROM app_info WHERE packageName = :packageName")
    suspend fun deleteAppInfo(packageName: String)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCleanHistory(cleanHistory: CleanHistoryEntity)
    
    @Query("SELECT * FROM clean_history WHERE cleanType = 'MEMORY' ORDER BY cleanTime DESC LIMIT :limit")
    fun getMemoryCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>>
}
