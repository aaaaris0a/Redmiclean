package com.redmicleaner.app.data.repository

import android.content.Context
import android.content.pm.PackageManager
import com.redmicleaner.app.data.database.dao.PrivacyProtectionDao
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import com.redmicleaner.app.data.database.entity.PrivacyRiskEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

class PrivacyProtectionRepositoryImpl @Inject constructor(
    private val context: Context,
    private val privacyProtectionDao: PrivacyProtectionDao
) : PrivacyProtectionRepository {

    override suspend fun scanPrivacyRisks(): List<PrivacyRiskEntity> = withContext(Dispatchers.IO) {
        val privacyRisks = mutableListOf<PrivacyRiskEntity>()
        val packageManager = context.packageManager
        val installedPackages = packageManager.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        
        for (packageInfo in installedPackages) {
            try {
                val packageName = packageInfo.packageName
                val applicationInfo = packageManager.getApplicationInfo(packageName, 0)
                val appName = packageManager.getApplicationLabel(applicationInfo).toString()
                
                // 跳过系统应用和自己
                if ((applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0 ||
                    packageName == "com.redmicleaner.app") {
                    continue
                }
                
                // 检查危险权限
                val requestedPermissions = packageInfo.requestedPermissions
                if (requestedPermissions != null) {
                    for (permission in requestedPermissions) {
                        val permissionInfo = try {
                            packageManager.getPermissionInfo(permission, 0)
                        } catch (e: Exception) {
                            continue
                        }
                        
                        // 检查是否为危险权限
                        if ((permissionInfo.protectionLevel and android.content.pm.PermissionInfo.PROTECTION_DANGEROUS) != 0) {
                            val riskLevel = when {
                                permission.contains("LOCATION") -> 3 // 高风险
                                permission.contains("CAMERA") || permission.contains("RECORD_AUDIO") -> 3 // 高风险
                                permission.contains("CONTACTS") || permission.contains("CALL_LOG") -> 2 // 中风险
                                permission.contains("STORAGE") -> 1 // 低风险
                                else -> 1 // 默认低风险
                            }
                            
                            val description = when {
                                permission.contains("LOCATION") -> "应用可以获取您的位置信息"
                                permission.contains("CAMERA") -> "应用可以使用相机拍照和录像"
                                permission.contains("RECORD_AUDIO") -> "应用可以录制音频"
                                permission.contains("CONTACTS") -> "应用可以读取您的联系人"
                                permission.contains("CALL_LOG") -> "应用可以读取您的通话记录"
                                permission.contains("STORAGE") -> "应用可以读写您的存储空间"
                                else -> "应用使用了危险权限：$permission"
                            }
                            
                            val privacyRisk = PrivacyRiskEntity(
                                packageName = packageName,
                                appName = appName,
                                riskType = "PERMISSION",
                                riskLevel = riskLevel,
                                description = description,
                                detectionTime = System.currentTimeMillis()
                            )
                            
                            privacyRisks.add(privacyRisk)
                        }
                    }
                }
                
                // 检查是否有自启动行为
                val bootReceiverIntent = android.content.Intent(android.content.Intent.ACTION_BOOT_COMPLETED)
                val receivers = packageManager.queryBroadcastReceivers(bootReceiverIntent, 0)
                for (resolveInfo in receivers) {
                    if (resolveInfo.activityInfo.packageName == packageName) {
                        val privacyRisk = PrivacyRiskEntity(
                            packageName = packageName,
                            appName = appName,
                            riskType = "AUTOSTART",
                            riskLevel = 2, // 中风险
                            description = "应用会在开机时自动启动",
                            detectionTime = System.currentTimeMillis()
                        )
                        
                        privacyRisks.add(privacyRisk)
                        break
                    }
                }
            } catch (e: Exception) {
                // 忽略无法访问的应用
                e.printStackTrace()
            }
        }
        
        // 检查浏览器历史记录和Cookie
        scanBrowserPrivacyRisks(privacyRisks)
        
        // 保存扫描结果到数据库
        privacyProtectionDao.insertPrivacyRisks(privacyRisks)
        
        return@withContext privacyRisks
    }
    
    override fun getAllPrivacyRisks(): Flow<List<PrivacyRiskEntity>> {
        return privacyProtectionDao.getAllPrivacyRisks()
    }
    
    override fun getPrivacyRisksByPackage(packageName: String): Flow<List<PrivacyRiskEntity>> {
        return privacyProtectionDao.getPrivacyRisksByPackage(packageName)
    }
    
    override fun getPrivacyRisksByType(riskType: String): Flow<List<PrivacyRiskEntity>> {
        return privacyProtectionDao.getPrivacyRisksByType(riskType)
    }
    
    override fun getPrivacyRisksByLevel(minLevel: Int): Flow<List<PrivacyRiskEntity>> {
        return privacyProtectionDao.getPrivacyRisksByLevel(minLevel)
    }
    
    override suspend fun getPrivacyRiskCount(): Int {
        return privacyProtectionDao.getPrivacyRiskCount()
    }
    
    override suspend fun getPrivacyRiskCountByLevel(level: Int): Int {
        return privacyProtectionDao.getPrivacyRiskCountByLevel(level)
    }
    
    override suspend fun getPrivacyScore(): Int = withContext(Dispatchers.IO) {
        val totalRisks = getPrivacyRiskCount()
        if (totalRisks == 0) {
            return@withContext 100
        }
        
        val highRisks = getPrivacyRiskCountByLevel(3) * 3
        val mediumRisks = getPrivacyRiskCountByLevel(2) * 2
        val lowRisks = getPrivacyRiskCountByLevel(1)
        
        val riskScore = highRisks + mediumRisks + lowRisks
        val maxScore = totalRisks * 3
        
        val privacyScore = 100 - (riskScore * 100 / maxScore)
        return@withContext privacyScore.coerceIn(0, 100)
    }
    
    override suspend fun fixPrivacyRisk(id: Int): Boolean = withContext(Dispatchers.IO) {
        try {
            privacyProtectionDao.deletePrivacyRisk(id)
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        }
    }
    
    override suspend fun fixPrivacyRisksByPackage(packageName: String): Int = withContext(Dispatchers.IO) {
        try {
            val risks = privacyProtectionDao.getPrivacyRisksByPackage(packageName).first()
            privacyProtectionDao.deletePrivacyRisksByPackage(packageName)
            return@withContext risks.size
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext 0
        }
    }
    
    override suspend fun fixAllPrivacyRisks(): Int = withContext(Dispatchers.IO) {
        try {
            val count = getPrivacyRiskCount()
            privacyProtectionDao.deleteAllPrivacyRisks()
            return@withContext count
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext 0
        }
    }
    
    override suspend fun cleanPrivacyData(): Long = withContext(Dispatchers.IO) {
        var cleanedSize = 0L
        
        // 清理浏览器历史记录和Cookie
        cleanedSize += cleanBrowserData()
        
        // 清理剪贴板
        val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboardManager.setPrimaryClip(android.content.ClipData.newPlainText("", ""))
        
        // 清理应用使用记录
        // 注意：这需要特殊权限，这里简化处理
        
        return@withContext cleanedSize
    }
    
    override suspend fun saveCleanHistory(cleanedItems: Int, details: String) {
        val cleanHistory = CleanHistoryEntity(
            cleanType = "PRIVACY",
            cleanTime = System.currentTimeMillis(),
            cleanedSize = cleanedItems.toLong(),
            details = details
        )
        privacyProtectionDao.insertCleanHistory(cleanHistory)
    }
    
    override fun getCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>> {
        return privacyProtectionDao.getPrivacyCleanHistory(limit)
    }
    
    // 辅助方法
    
    private suspend fun scanBrowserPrivacyRisks(privacyRisks: MutableList<PrivacyRiskEntity>) {
        // 检查Chrome浏览器历史记录和Cookie
        val chromeHistoryFile = File("/data/data/com.android.chrome/app_chrome/Default/History")
        if (chromeHistoryFile.exists()) {
            privacyRisks.add(
                PrivacyRiskEntity(
                    packageName = "com.android.chrome",
                    appName = "Chrome浏览器",
                    riskType = "BROWSER_HISTORY",
                    riskLevel = 2, // 中风险
                    description = "Chrome浏览器历史记录可能包含敏感信息",
                    detectionTime = System.currentTimeMillis()
                )
            )
        }
        
        val chromeCookiesFile = File("/data/data/com.android.chrome/app_chrome/Default/Cookies")
        if (chromeCookiesFile.exists()) {
            privacyRisks.add(
                PrivacyRiskEntity(
                    packageName = "com.android.chrome",
                    appName = "Chrome浏览器",
                    riskType = "BROWSER_COOKIES",
                    riskLevel = 2, // 中风险
                    description = "Chrome浏览器Cookie可能包含登录信息",
                    detectionTime = System.currentTimeMillis()
                )
            )
        }
        
        // 检查系统浏览器历史记录和Cookie
        val systemBrowserHistoryFile = File("/data/data/com.android.browser/databases/browser.db")
        if (systemBrowserHistoryFile.exists()) {
            privacyRisks.add(
                PrivacyRiskEntity(
                    packageName = "com.android.browser",
                    appName = "系统浏览器",
                    riskType = "BROWSER_HISTORY",
                    riskLevel = 2, // 中风险
                    description = "系统浏览器历史记录可能包含敏感信息",
                    detectionTime = System.currentTimeMillis()
                )
            )
        }
    }
    
    private suspend fun cleanBrowserData(): Long = withContext(Dispatchers.IO) {
        var cleanedSize = 0L
        
        // 清理Chrome浏览器历史记录和Cookie
        val chromeHistoryFile = File("/data/data/com.android.chrome/app_chrome/Default/History")
        if (chromeHistoryFile.exists()) {
            cleanedSize += chromeHistoryFile.length()
            chromeHistoryFile.delete()
        }
        
        val chromeCookiesFile = File("/data/data/com.android.chrome/app_chrome/Default/Cookies")
        if (chromeCookiesFile.exists()) {
            cleanedSize += chromeCookiesFile.length()
            chromeCookiesFile.delete()
        }
        
        // 清理系统浏览器历史记录和Cookie
        val systemBrowserHistoryFile = File("/data/data/com.android.browser/databases/browser.db")
        if (systemBrowserHistoryFile.exists()) {
            cleanedSize += systemBrowserHistoryFile.length()
            systemBrowserHistoryFile.delete()
        }
        
        return@withContext cleanedSize
    }
}
