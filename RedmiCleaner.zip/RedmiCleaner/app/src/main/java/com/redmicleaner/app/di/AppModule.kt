package com.redmicleaner.app.di

import android.content.Context
import androidx.room.Room
import com.redmicleaner.app.data.database.CleanerDatabase
import com.redmicleaner.app.data.repository.CacheCleanerRepository
import com.redmicleaner.app.data.repository.CacheCleanerRepositoryImpl
import com.redmicleaner.app.data.repository.MemoryOptimizerRepository
import com.redmicleaner.app.data.repository.MemoryOptimizerRepositoryImpl
import com.redmicleaner.app.data.repository.PrivacyProtectionRepository
import com.redmicleaner.app.data.repository.PrivacyProtectionRepositoryImpl
import com.redmicleaner.app.data.repository.ResidualCleanerRepository
import com.redmicleaner.app.data.repository.ResidualCleanerRepositoryImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    
    @Provides
    @Singleton
    fun provideCleanerDatabase(@ApplicationContext context: Context): CleanerDatabase {
        return Room.databaseBuilder(
            context,
            CleanerDatabase::class.java,
            "cleaner_database"
        ).build()
    }
    
    @Provides
    @Singleton
    fun provideCacheCleanerRepository(
        @ApplicationContext context: Context,
        database: CleanerDatabase
    ): CacheCleanerRepository {
        return CacheCleanerRepositoryImpl(context, database.cacheCleanerDao())
    }
    
    @Provides
    @Singleton
    fun provideMemoryOptimizerRepository(
        @ApplicationContext context: Context,
        database: CleanerDatabase
    ): MemoryOptimizerRepository {
        return MemoryOptimizerRepositoryImpl(context, database.memoryOptimizerDao())
    }
    
    @Provides
    @Singleton
    fun provideResidualCleanerRepository(
        @ApplicationContext context: Context,
        database: CleanerDatabase
    ): ResidualCleanerRepository {
        return ResidualCleanerRepositoryImpl(context, database.residualCleanerDao())
    }
    
    @Provides
    @Singleton
    fun providePrivacyProtectionRepository(
        @ApplicationContext context: Context,
        database: CleanerDatabase
    ): PrivacyProtectionRepository {
        return PrivacyProtectionRepositoryImpl(context, database.privacyProtectionDao())
    }
}
