package com.redmicleaner.app.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import com.redmicleaner.app.data.database.entity.ResidualFileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ResidualCleanerDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResidualFile(residualFile: ResidualFileEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResidualFiles(residualFiles: List<ResidualFileEntity>)
    
    @Query("SELECT * FROM residual_file ORDER BY fileSize DESC")
    fun getAllResidualFiles(): Flow<List<ResidualFileEntity>>
    
    @Query("SELECT * FROM residual_file WHERE packageName = :packageName")
    fun getResidualFilesByPackage(packageName: String): Flow<List<ResidualFileEntity>>
    
    @Query("SELECT * FROM residual_file WHERE fileType = :fileType")
    fun getResidualFilesByType(fileType: String): Flow<List<ResidualFileEntity>>
    
    @Query("SELECT SUM(fileSize) FROM residual_file")
    suspend fun getTotalResidualSize(): Long?
    
    @Query("UPDATE residual_file SET isSelected = :isSelected WHERE filePath = :filePath")
    suspend fun updateResidualFileSelection(filePath: String, isSelected: Boolean)
    
    @Query("UPDATE residual_file SET isSelected = :isSelected")
    suspend fun updateAllResidualFileSelection(isSelected: Boolean)
    
    @Query("DELETE FROM residual_file WHERE filePath = :filePath")
    suspend fun deleteResidualFile(filePath: String)
    
    @Query("DELETE FROM residual_file WHERE isSelected = 1")
    suspend fun deleteSelectedResidualFiles()
    
    @Query("DELETE FROM residual_file")
    suspend fun deleteAllResidualFiles()
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCleanHistory(cleanHistory: CleanHistoryEntity)
    
    @Query("SELECT * FROM clean_history WHERE cleanType = 'RESIDUAL' ORDER BY cleanTime DESC LIMIT :limit")
    fun getResidualCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>>
}
