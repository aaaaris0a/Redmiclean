package com.redmicleaner.app.data.repository

import android.content.Context
import android.content.pm.PackageManager
import com.redmicleaner.app.data.database.dao.ResidualCleanerDao
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import com.redmicleaner.app.data.database.entity.ResidualFileEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

class ResidualCleanerRepositoryImpl @Inject constructor(
    private val context: Context,
    private val residualCleanerDao: ResidualCleanerDao
) : ResidualCleanerRepository {

    override suspend fun scanResidualFiles(): List<ResidualFileEntity> = withContext(Dispatchers.IO) {
        val residualFiles = mutableListOf<ResidualFileEntity>()
        val packageManager = context.packageManager
        val installedPackages = packageManager.getInstalledPackages(0)
        val installedPackageNames = installedPackages.map { it.packageName }
        
        // 扫描内部存储中的应用数据目录
        scanInternalDataDirectory(residualFiles, installedPackageNames)
        
        // 扫描外部存储中的应用数据目录
        scanExternalDataDirectory(residualFiles, installedPackageNames)
        
        // 扫描下载目录中的残留文件
        scanDownloadDirectory(residualFiles)
        
        // 保存扫描结果到数据库
        residualCleanerDao.insertResidualFiles(residualFiles)
        
        return@withContext residualFiles
    }
    
    override fun getAllResidualFiles(): Flow<List<ResidualFileEntity>> {
        return residualCleanerDao.getAllResidualFiles()
    }
    
    override fun getResidualFilesByPackage(packageName: String): Flow<List<ResidualFileEntity>> {
        return residualCleanerDao.getResidualFilesByPackage(packageName)
    }
    
    override fun getResidualFilesByType(fileType: String): Flow<List<ResidualFileEntity>> {
        return residualCleanerDao.getResidualFilesByType(fileType)
    }
    
    override suspend fun getTotalResidualSize(): Long {
        return residualCleanerDao.getTotalResidualSize() ?: 0L
    }
    
    override suspend fun updateResidualFileSelection(filePath: String, isSelected: Boolean) {
        residualCleanerDao.updateResidualFileSelection(filePath, isSelected)
    }
    
    override suspend fun updateAllResidualFileSelection(isSelected: Boolean) {
        residualCleanerDao.updateAllResidualFileSelection(isSelected)
    }
    
    override suspend fun cleanResidualFile(filePath: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            val success = if (file.isDirectory) {
                deleteDir(file)
            } else {
                file.delete()
            }
            
            if (success) {
                residualCleanerDao.deleteResidualFile(filePath)
            }
            
            return@withContext success
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        }
    }
    
    override suspend fun cleanSelectedResidualFiles(): Long = withContext(Dispatchers.IO) {
        var totalCleaned = 0L
        val residualFiles = residualCleanerDao.getAllResidualFiles().first()
        
        for (residualFile in residualFiles) {
            if (residualFile.isSelected) {
                val success = cleanResidualFile(residualFile.filePath)
                if (success) {
                    totalCleaned += residualFile.fileSize
                }
            }
        }
        
        // 删除数据库中已选择的残留文件记录
        residualCleanerDao.deleteSelectedResidualFiles()
        
        return@withContext totalCleaned
    }
    
    override suspend fun cleanAllResidualFiles(): Long = withContext(Dispatchers.IO) {
        val totalResidualSize = getTotalResidualSize()
        val residualFiles = residualCleanerDao.getAllResidualFiles().first()
        
        for (residualFile in residualFiles) {
            cleanResidualFile(residualFile.filePath)
        }
        
        // 删除数据库中所有残留文件记录
        residualCleanerDao.deleteAllResidualFiles()
        
        return@withContext totalResidualSize
    }
    
    override suspend fun saveCleanHistory(cleanedSize: Long, details: String) {
        val cleanHistory = CleanHistoryEntity(
            cleanType = "RESIDUAL",
            cleanTime = System.currentTimeMillis(),
            cleanedSize = cleanedSize,
            details = details
        )
        residualCleanerDao.insertCleanHistory(cleanHistory)
    }
    
    override fun getCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>> {
        return residualCleanerDao.getResidualCleanHistory(limit)
    }
    
    // 辅助方法
    
    private suspend fun scanInternalDataDirectory(
        residualFiles: MutableList<ResidualFileEntity>,
        installedPackageNames: List<String>
    ) {
        val dataDir = File("/data/data")
        if (!dataDir.exists() || !dataDir.isDirectory || !dataDir.canRead()) {
            return
        }
        
        val packageDirs = dataDir.listFiles() ?: return
        
        for (packageDir in packageDirs) {
            if (!packageDir.isDirectory) continue
            
            val packageName = packageDir.name
            if (packageName in installedPackageNames) continue
            
            // 这是一个已卸载应用的数据目录
            val appName = getAppNameFromPackage(packageName) ?: "未知应用"
            val fileSize = getDirSize(packageDir)
            
            val residualFile = ResidualFileEntity(
                filePath = packageDir.absolutePath,
                fileName = packageDir.name,
                fileSize = fileSize,
                packageName = packageName,
                appName = appName,
                fileType = "DATA",
                lastModifiedTime = packageDir.lastModified(),
                isSelected = false
            )
            
            residualFiles.add(residualFile)
        }
    }
    
    private suspend fun scanExternalDataDirectory(
        residualFiles: MutableList<ResidualFileEntity>,
        installedPackageNames: List<String>
    ) {
        val externalDir = context.getExternalFilesDir(null)?.parentFile?.parentFile
        if (externalDir == null || !externalDir.exists() || !externalDir.isDirectory) {
            return
        }
        
        val androidDataDir = File(externalDir, "Android/data")
        if (!androidDataDir.exists() || !androidDataDir.isDirectory) {
            return
        }
        
        val packageDirs = androidDataDir.listFiles() ?: return
        
        for (packageDir in packageDirs) {
            if (!packageDir.isDirectory) continue
            
            val packageName = packageDir.name
            if (packageName in installedPackageNames) continue
            
            // 这是一个已卸载应用的数据目录
            val appName = getAppNameFromPackage(packageName) ?: "未知应用"
            val fileSize = getDirSize(packageDir)
            
            val residualFile = ResidualFileEntity(
                filePath = packageDir.absolutePath,
                fileName = packageDir.name,
                fileSize = fileSize,
                packageName = packageName,
                appName = appName,
                fileType = "DATA",
                lastModifiedTime = packageDir.lastModified(),
                isSelected = false
            )
            
            residualFiles.add(residualFile)
        }
    }
    
    private suspend fun scanDownloadDirectory(residualFiles: MutableList<ResidualFileEntity>) {
        val downloadDir = context.getExternalFilesDir(null)?.parentFile?.parentFile
            ?.let { File(it, "Download") }
        
        if (downloadDir == null || !downloadDir.exists() || !downloadDir.isDirectory) {
            return
        }
        
        val files = downloadDir.listFiles() ?: return
        
        for (file in files) {
            // 检查是否为APK文件
            if (file.isFile && file.name.endsWith(".apk")) {
                val fileSize = file.length()
                
                val residualFile = ResidualFileEntity(
                    filePath = file.absolutePath,
                    fileName = file.name,
                    fileSize = fileSize,
                    packageName = "",
                    appName = "安装包",
                    fileType = "APK",
                    lastModifiedTime = file.lastModified(),
                    isSelected = false
                )
                
                residualFiles.add(residualFile)
            }
            
            // 检查是否为临时文件
            if (file.isFile && (file.name.endsWith(".tmp") || file.name.contains(".temp"))) {
                val fileSize = file.length()
                
                val residualFile = ResidualFileEntity(
                    filePath = file.absolutePath,
                    fileName = file.name,
                    fileSize = fileSize,
                    packageName = "",
                    appName = "临时文件",
                    fileType = "TEMP",
                    lastModifiedTime = file.lastModified(),
                    isSelected = false
                )
                
                residualFiles.add(residualFile)
            }
        }
    }
    
    private fun getAppNameFromPackage(packageName: String): String? {
        return try {
            val applicationInfo = context.packageManager.getApplicationInfo(packageName, 0)
            context.packageManager.getApplicationLabel(applicationInfo).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }
    
    private fun getDirSize(dir: File): Long {
        var size = 0L
        if (dir.exists()) {
            val files = dir.listFiles()
            if (files != null) {
                for (file in files) {
                    size += if (file.isDirectory) {
                        getDirSize(file)
                    } else {
                        file.length()
                    }
                }
            }
        }
        return size
    }
    
    private fun deleteDir(dir: File): Boolean {
        if (dir.exists()) {
            val files = dir.listFiles()
            if (files != null) {
                for (file in files) {
                    if (file.isDirectory) {
                        deleteDir(file)
                    } else {
                        file.delete()
                    }
                }
            }
        }
        return dir.delete()
    }
}
