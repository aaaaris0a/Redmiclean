package com.redmicleaner.app.data.repository

import com.redmicleaner.app.data.database.entity.AppInfoEntity
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import kotlinx.coroutines.flow.Flow

interface MemoryOptimizerRepository {
    suspend fun scanRunningApps(): List<AppInfoEntity>
    suspend fun getAppInfoByPackage(packageName: String): AppInfoEntity?
    fun getAllAppInfos(): Flow<List<AppInfoEntity>>
    fun getNonSystemApps(): Flow<List<AppInfoEntity>>
    fun getSystemApps(): Flow<List<AppInfoEntity>>
    suspend fun getTotalMemoryUsage(): Long
    suspend fun getAvailableMemory(): Long
    suspend fun getTotalMemory(): Long
    suspend fun killApp(packageName: String): Boolean
    suspend fun killSelectedApps(packageNames: List<String>): Long
    suspend fun killAllApps(): Long
    suspend fun optimizeMemory(): Long
    suspend fun saveCleanHistory(freedMemory: Long, details: String)
    fun getCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>>
}
