package com.redmicleaner.app.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import com.redmicleaner.app.data.database.entity.PrivacyRiskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PrivacyProtectionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrivacyRisk(privacyRisk: PrivacyRiskEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrivacyRisks(privacyRisks: List<PrivacyRiskEntity>)
    
    @Query("SELECT * FROM privacy_risk ORDER BY riskLevel DESC")
    fun getAllPrivacyRisks(): Flow<List<PrivacyRiskEntity>>
    
    @Query("SELECT * FROM privacy_risk WHERE packageName = :packageName")
    fun getPrivacyRisksByPackage(packageName: String): Flow<List<PrivacyRiskEntity>>
    
    @Query("SELECT * FROM privacy_risk WHERE riskType = :riskType")
    fun getPrivacyRisksByType(riskType: String): Flow<List<PrivacyRiskEntity>>
    
    @Query("SELECT * FROM privacy_risk WHERE riskLevel >= :minLevel")
    fun getPrivacyRisksByLevel(minLevel: Int): Flow<List<PrivacyRiskEntity>>
    
    @Query("SELECT COUNT(*) FROM privacy_risk")
    suspend fun getPrivacyRiskCount(): Int
    
    @Query("SELECT COUNT(*) FROM privacy_risk WHERE riskLevel = :level")
    suspend fun getPrivacyRiskCountByLevel(level: Int): Int
    
    @Query("DELETE FROM privacy_risk WHERE id = :id")
    suspend fun deletePrivacyRisk(id: Int)
    
    @Query("DELETE FROM privacy_risk WHERE packageName = :packageName")
    suspend fun deletePrivacyRisksByPackage(packageName: String)
    
    @Query("DELETE FROM privacy_risk")
    suspend fun deleteAllPrivacyRisks()
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCleanHistory(cleanHistory: CleanHistoryEntity)
    
    @Query("SELECT * FROM clean_history WHERE cleanType = 'PRIVACY' ORDER BY cleanTime DESC LIMIT :limit")
    fun getPrivacyCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>>
}
