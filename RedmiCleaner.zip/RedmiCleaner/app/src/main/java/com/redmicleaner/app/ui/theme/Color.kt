package com.redmicleaner.app.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFF1E88E5)
val BlueGrey80 = Color(0xFF78909C)
val Green80 = Color(0xFF43A047)
val Red80 = Color(0xFFE53935)

val Blue40 = Color(0xFF1565C0)
val BlueGrey40 = Color(0xFF546E7A)
val Green40 = Color(0xFF2E7D32)
val Red40 = Color(0xFFC62828)
