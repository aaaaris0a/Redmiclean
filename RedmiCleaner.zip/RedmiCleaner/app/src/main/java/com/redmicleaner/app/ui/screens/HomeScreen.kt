package com.redmicleaner.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun HomeScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 顶部状态卡片
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "设备健康评分: 85",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "系统运行良好，建议清理缓存",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(
                    onClick = { /* 一键优化逻辑 */ },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("一键优化")
                }
            }
        }
        
        // 功能网格
        Text(
            text = "清理工具",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier
                .align(Alignment.Start)
                .padding(vertical = 8.dp)
        )
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            FunctionButton(
                title = "缓存清理",
                onClick = { /* 导航到缓存清理页面 */ }
            )
            FunctionButton(
                title = "内存优化",
                onClick = { /* 导航到内存优化页面 */ }
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            FunctionButton(
                title = "残留清理",
                onClick = { /* 导航到残留清理页面 */ }
            )
            FunctionButton(
                title = "隐私保护",
                onClick = { /* 导航到隐私保护页面 */ }
            )
        }
        
        // 智能推荐区
        Text(
            text = "智能推荐",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier
                .align(Alignment.Start)
                .padding(top = 24.dp, bottom = 8.dp)
        )
        
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "推荐清理: 微信缓存 (1.2GB)",
                    style = MaterialTheme.typography.bodyLarge
                )
                Button(
                    onClick = { /* 清理微信缓存逻辑 */ },
                    modifier = Modifier
                        .align(Alignment.End)
                        .padding(top = 8.dp)
                ) {
                    Text("立即清理")
                }
            }
        }
        
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "内存使用: 65%",
                    style = MaterialTheme.typography.bodyLarge
                )
                Button(
                    onClick = { /* 释放内存逻辑 */ },
                    modifier = Modifier
                        .align(Alignment.End)
                        .padding(top = 8.dp)
                ) {
                    Text("释放内存")
                }
            }
        }
    }
}

@Composable
fun FunctionButton(
    title: String,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .width(150.dp)
            .height(100.dp)
    ) {
        Text(
            text = title,
            textAlign = TextAlign.Center
        )
    }
}
