package com.redmicleaner.app.data.repository

import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import com.redmicleaner.app.data.database.entity.ResidualFileEntity
import kotlinx.coroutines.flow.Flow

interface ResidualCleanerRepository {
    suspend fun scanResidualFiles(): List<ResidualFileEntity>
    fun getAllResidualFiles(): Flow<List<ResidualFileEntity>>
    fun getResidualFilesByPackage(packageName: String): Flow<List<ResidualFileEntity>>
    fun getResidualFilesByType(fileType: String): Flow<List<ResidualFileEntity>>
    suspend fun getTotalResidualSize(): Long
    suspend fun updateResidualFileSelection(filePath: String, isSelected: Boolean)
    suspend fun updateAllResidualFileSelection(isSelected: Boolean)
    suspend fun cleanResidualFile(filePath: String): Boolean
    suspend fun cleanSelectedResidualFiles(): Long
    suspend fun cleanAllResidualFiles(): Long
    suspend fun saveCleanHistory(cleanedSize: Long, details: String)
    fun getCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>>
}
