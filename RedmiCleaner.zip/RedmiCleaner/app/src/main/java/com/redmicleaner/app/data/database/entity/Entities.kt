package com.redmicleaner.app.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_cache")
data class AppCacheEntity(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val cacheSize: Long,
    val lastScanTime: Long
)

@Entity(tableName = "app_info")
data class AppInfoEntity(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val versionName: String,
    val installTime: Long,
    val lastUpdateTime: Long,
    val isSystemApp: Boolean,
    val memoryUsage: Long,
    val batteryUsage: Float,
    val dataUsage: Long,
    val lastUsedTime: Long
)

@Entity(tableName = "clean_history")
data class CleanHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val cleanType: String, // CACHE, MEMORY, RESIDUAL, PRIVACY
    val cleanTime: Long,
    val cleanedSize: Long,
    val details: String // JSON格式的详细信息
)

@Entity(tableName = "privacy_risk")
data class PrivacyRiskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val packageName: String,
    val appName: String,
    val riskType: String, // PERMISSION, DATA_LEAK, TRACKING
    val riskLevel: Int, // 1-低, 2-中, 3-高
    val description: String,
    val detectionTime: Long
)

@Entity(tableName = "residual_file")
data class ResidualFileEntity(
    @PrimaryKey
    val filePath: String,
    val fileName: String,
    val fileSize: Long,
    val packageName: String, // 可能为空，表示未知来源
    val appName: String, // 可能为空，表示未知来源
    val fileType: String, // DATA, CACHE, LOG, TEMP
    val lastModifiedTime: Long,
    val isSelected: Boolean = false
)
