package com.redmicleaner.app.data.repository

import android.content.Context
import android.os.Environment
import android.os.StatFs
import com.redmicleaner.app.data.database.dao.CacheCleanerDao
import com.redmicleaner.app.data.database.entity.AppCacheEntity
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

class CacheCleanerRepositoryImpl @Inject constructor(
    private val context: Context,
    private val cacheCleanerDao: CacheCleanerDao
) : CacheCleanerRepository {

    override suspend fun scanAppCaches(): List<AppCacheEntity> = withContext(Dispatchers.IO) {
        val packageManager = context.packageManager
        val installedPackages = packageManager.getInstalledPackages(0)
        val appCaches = mutableListOf<AppCacheEntity>()
        
        for (packageInfo in installedPackages) {
            try {
                val applicationInfo = packageManager.getApplicationInfo(packageInfo.packageName, 0)
                val appName = packageManager.getApplicationLabel(applicationInfo).toString()
                
                // 内部缓存
                var cacheSize = 0L
                applicationInfo.dataDir?.let { dataDir ->
                    val cachePath = "$dataDir/cache"
                    val cacheDir = File(cachePath)
                    if (cacheDir.exists() && cacheDir.isDirectory) {
                        cacheSize += getDirSize(cacheDir)
                    }
                }
                
                // 外部缓存
                val externalCacheDir = context.getExternalFilesDir(null)?.parentFile
                if (externalCacheDir != null) {
                    val externalAppCacheDir = File(externalCacheDir, packageInfo.packageName)
                    if (externalAppCacheDir.exists() && externalAppCacheDir.isDirectory) {
                        cacheSize += getDirSize(externalAppCacheDir)
                    }
                }
                
                // 只添加有缓存的应用
                if (cacheSize > 0) {
                    val appCache = AppCacheEntity(
                        packageName = packageInfo.packageName,
                        appName = appName,
                        cacheSize = cacheSize,
                        lastScanTime = System.currentTimeMillis()
                    )
                    appCaches.add(appCache)
                    cacheCleanerDao.insertAppCache(appCache)
                }
            } catch (e: Exception) {
                // 忽略无法访问的应用
                e.printStackTrace()
            }
        }
        
        // 扫描系统缓存
        val systemCacheSize = scanSystemCache()
        if (systemCacheSize > 0) {
            val systemCache = AppCacheEntity(
                packageName = "system",
                appName = "系统缓存",
                cacheSize = systemCacheSize,
                lastScanTime = System.currentTimeMillis()
            )
            appCaches.add(systemCache)
            cacheCleanerDao.insertAppCache(systemCache)
        }
        
        return@withContext appCaches
    }
    
    override suspend fun getAppCacheByPackage(packageName: String): AppCacheEntity? {
        return cacheCleanerDao.getAppCacheByPackage(packageName)
    }
    
    override fun getAllAppCaches(): Flow<List<AppCacheEntity>> {
        return cacheCleanerDao.getAllAppCaches()
    }
    
    override suspend fun getTotalCacheSize(): Long {
        return cacheCleanerDao.getTotalCacheSize() ?: 0L
    }
    
    override suspend fun cleanAppCache(packageName: String): Boolean = withContext(Dispatchers.IO) {
        try {
            if (packageName == "system") {
                // 清理系统缓存
                cleanSystemCache()
            } else {
                // 清理应用缓存
                val applicationInfo = context.packageManager.getApplicationInfo(packageName, 0)
                
                // 清理内部缓存
                applicationInfo.dataDir?.let { dataDir ->
                    val cachePath = "$dataDir/cache"
                    val cacheDir = File(cachePath)
                    if (cacheDir.exists() && cacheDir.isDirectory) {
                        deleteDir(cacheDir)
                    }
                }
                
                // 清理外部缓存
                val externalCacheDir = context.getExternalFilesDir(null)?.parentFile
                if (externalCacheDir != null) {
                    val externalAppCacheDir = File(externalCacheDir, packageName)
                    if (externalAppCacheDir.exists() && externalAppCacheDir.isDirectory) {
                        deleteDir(externalAppCacheDir)
                    }
                }
            }
            
            // 从数据库中删除缓存记录
            cacheCleanerDao.deleteAppCache(packageName)
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        }
    }
    
    override suspend fun cleanSelectedAppCaches(packageNames: List<String>): Long = withContext(Dispatchers.IO) {
        var totalCleaned = 0L
        
        for (packageName in packageNames) {
            val appCache = getAppCacheByPackage(packageName)
            if (appCache != null) {
                val cacheSize = appCache.cacheSize
                val success = cleanAppCache(packageName)
                if (success) {
                    totalCleaned += cacheSize
                }
            }
        }
        
        return@withContext totalCleaned
    }
    
    override suspend fun cleanAllAppCaches(): Long = withContext(Dispatchers.IO) {
        val totalCacheSize = getTotalCacheSize()
        val appCaches = cacheCleanerDao.getAllAppCaches().first()
        
        for (appCache in appCaches) {
            cleanAppCache(appCache.packageName)
        }
        
        return@withContext totalCacheSize
    }
    
    override suspend fun saveCleanHistory(cleanedSize: Long, details: String) {
        val cleanHistory = CleanHistoryEntity(
            cleanType = "CACHE",
            cleanTime = System.currentTimeMillis(),
            cleanedSize = cleanedSize,
            details = details
        )
        cacheCleanerDao.insertCleanHistory(cleanHistory)
    }
    
    override fun getCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>> {
        return cacheCleanerDao.getCacheCleanHistory(limit)
    }
    
    // 辅助方法
    
    private fun getDirSize(dir: File): Long {
        var size = 0L
        if (dir.exists()) {
            val files = dir.listFiles()
            if (files != null) {
                for (file in files) {
                    size += if (file.isDirectory) {
                        getDirSize(file)
                    } else {
                        file.length()
                    }
                }
            }
        }
        return size
    }
    
    private fun deleteDir(dir: File): Boolean {
        if (dir.exists()) {
            val files = dir.listFiles()
            if (files != null) {
                for (file in files) {
                    if (file.isDirectory) {
                        deleteDir(file)
                    } else {
                        file.delete()
                    }
                }
            }
        }
        return dir.delete()
    }
    
    private fun scanSystemCache(): Long {
        var systemCacheSize = 0L
        
        // 扫描常见的系统缓存目录
        val cacheDirs = listOf(
            "/data/dalvik-cache",
            "/cache",
            "/data/log",
            "/data/tombstones"
        )
        
        for (cacheDir in cacheDirs) {
            val dir = File(cacheDir)
            if (dir.exists() && dir.isDirectory) {
                systemCacheSize += getDirSize(dir)
            }
        }
        
        // 扫描临时目录
        val tmpDir = File("/data/local/tmp")
        if (tmpDir.exists() && tmpDir.isDirectory) {
            systemCacheSize += getDirSize(tmpDir)
        }
        
        return systemCacheSize
    }
    
    private fun cleanSystemCache(): Boolean {
        var success = true
        
        // 清理常见的系统缓存目录
        val cacheDirs = listOf(
            "/data/log",
            "/data/tombstones",
            "/data/local/tmp"
        )
        
        for (cacheDir in cacheDirs) {
            val dir = File(cacheDir)
            if (dir.exists() && dir.isDirectory) {
                val result = deleteDir(dir)
                if (!result) {
                    success = false
                }
            }
        }
        
        return success
    }
}
