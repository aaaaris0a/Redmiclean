package com.redmicleaner.app.data.repository

import com.redmicleaner.app.data.database.entity.AppCacheEntity
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import kotlinx.coroutines.flow.Flow

interface CacheCleanerRepository {
    suspend fun scanAppCaches(): List<AppCacheEntity>
    suspend fun getAppCacheByPackage(packageName: String): AppCacheEntity?
    fun getAllAppCaches(): Flow<List<AppCacheEntity>>
    suspend fun getTotalCacheSize(): Long
    suspend fun cleanAppCache(packageName: String): Boolean
    suspend fun cleanSelectedAppCaches(packageNames: List<String>): Long
    suspend fun cleanAllAppCaches(): Long
    suspend fun saveCleanHistory(cleanedSize: Long, details: String)
    fun getCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>>
}
