package com.redmicleaner.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun ToolboxScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "工具箱",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        
        val tools = listOf(
            "存储空间分析",
            "电池优化",
            "通知管理",
            "定时任务",
            "应用管理",
            "网络测速",
            "文件加密",
            "垃圾短信过滤",
            "照片压缩"
        )
        
        LazyColumn {
            items(tools) { tool ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tool,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Button(
                            onClick = { /* 打开工具逻辑 */ }
                        ) {
                            Text("打开")
                        }
                    }
                }
            }
        }
    }
}
