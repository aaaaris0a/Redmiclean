package com.redmicleaner.app.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.redmicleaner.app.data.database.entity.AppCacheEntity
import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CacheCleanerDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppCache(appCache: AppCacheEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppCaches(appCaches: List<AppCacheEntity>)
    
    @Query("SELECT * FROM app_cache ORDER BY cacheSize DESC")
    fun getAllAppCaches(): Flow<List<AppCacheEntity>>
    
    @Query("SELECT * FROM app_cache WHERE packageName = :packageName")
    suspend fun getAppCacheByPackage(packageName: String): AppCacheEntity?
    
    @Query("SELECT SUM(cacheSize) FROM app_cache")
    suspend fun getTotalCacheSize(): Long?
    
    @Query("DELETE FROM app_cache WHERE packageName = :packageName")
    suspend fun deleteAppCache(packageName: String)
    
    @Query("DELETE FROM app_cache")
    suspend fun deleteAllAppCaches()
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCleanHistory(cleanHistory: CleanHistoryEntity)
    
    @Query("SELECT * FROM clean_history WHERE cleanType = 'CACHE' ORDER BY cleanTime DESC LIMIT :limit")
    fun getCacheCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>>
}
