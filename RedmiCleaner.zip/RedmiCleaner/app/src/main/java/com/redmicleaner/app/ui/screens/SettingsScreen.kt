package com.redmicleaner.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun SettingsScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "设置",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        
        val settings = listOf(
            "通用设置" to listOf(
                "深色模式" to true,
                "开机自启动" to false,
                "通知提醒" to true
            ),
            "清理设置" to listOf(
                "自动清理缓存" to false,
                "定时清理" to false,
                "清理白名单" to false
            ),
            "隐私设置" to listOf(
                "隐私扫描提醒" to true,
                "自动清理浏览记录" to false,
                "权限监控" to true
            ),
            "关于" to listOf(
                "版本信息" to false,
                "检查更新" to false,
                "用户协议" to false,
                "隐私政策" to false
            )
        )
        
        LazyColumn {
            settings.forEach { (category, items) ->
                item {
                    Text(
                        text = category,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    )
                }
                
                items(items) { (setting, isSwitch) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = setting,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            if (isSwitch) {
                                var checked by remember { mutableStateOf(false) }
                                Switch(
                                    checked = checked,
                                    onCheckedChange = { checked = it }
                                )
                            } else {
                                IconButton(onClick = { /* 打开设置详情 */ }) {
                                    Text(">")
                                }
                            }
                        }
                    }
                }
                
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
