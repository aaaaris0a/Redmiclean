package com.redmicleaner.app.data.repository

import com.redmicleaner.app.data.database.entity.CleanHistoryEntity
import com.redmicleaner.app.data.database.entity.PrivacyRiskEntity
import kotlinx.coroutines.flow.Flow

interface PrivacyProtectionRepository {
    suspend fun scanPrivacyRisks(): List<PrivacyRiskEntity>
    fun getAllPrivacyRisks(): Flow<List<PrivacyRiskEntity>>
    fun getPrivacyRisksByPackage(packageName: String): Flow<List<PrivacyRiskEntity>>
    fun getPrivacyRisksByType(riskType: String): Flow<List<PrivacyRiskEntity>>
    fun getPrivacyRisksByLevel(minLevel: Int): Flow<List<PrivacyRiskEntity>>
    suspend fun getPrivacyRiskCount(): Int
    suspend fun getPrivacyRiskCountByLevel(level: Int): Int
    suspend fun getPrivacyScore(): Int
    suspend fun fixPrivacyRisk(id: Int): Boolean
    suspend fun fixPrivacyRisksByPackage(packageName: String): Int
    suspend fun fixAllPrivacyRisks(): Int
    suspend fun cleanPrivacyData(): Long
    suspend fun saveCleanHistory(cleanedItems: Int, details: String)
    fun getCleanHistory(limit: Int): Flow<List<CleanHistoryEntity>>
}
